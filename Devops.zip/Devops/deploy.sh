#!/bin/bash

# AWS ECS configuration
AWS_REGION="your_aws_region"
ECS_CLUSTER_NAME="your_ecs_cluster_name"
ECS_SERVICE_NAME="your_ecs_service_name"
ECS_TASK_DEFINITION="your_ecs_task_definition_name"

# Docker image details
DOCKER_IMAGE="yourusername/yourimage"
TAG="latest"

# Authenticate Docker with AWS ECR (Elastic Container Registry)
aws ecr get-login-password --region $AWS_REGION | docker login --username AWS --password-stdin $ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com

# Build the Docker image
docker build -t $DOCKER_IMAGE:$TAG .

# Tag the Docker image for AWS ECR
docker tag $DOCKER_IMAGE:$TAG $ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/$DOCKER_IMAGE:$TAG

# Push the Docker image to AWS ECR
docker push $ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/$DOCKER_IMAGE:$TAG

# Update the ECS task definition with the new image version
aws ecs register-task-definition --region $AWS_REGION --cli-input-json file://ecs-task-definition.json

# Update the ECS service to use the latest task definition
aws ecs update-service --region $AWS_REGION --cluster $ECS_CLUSTER_NAME --service $ECS_SERVICE_NAME --task-definition $ECS_TASK_DEFINITION
