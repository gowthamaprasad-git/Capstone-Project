#!/bin/bash

IMAGE_NAME="prasad/react"
TAG="latest"

# Set the path to the Dockerfile
DOCKERFILE_PATH="."

# Build the Docker image
docker build -t $IMAGE_NAME:$TAG $DOCKERFILE_PATH

# Display the list of Docker images to verify the build
docker images
